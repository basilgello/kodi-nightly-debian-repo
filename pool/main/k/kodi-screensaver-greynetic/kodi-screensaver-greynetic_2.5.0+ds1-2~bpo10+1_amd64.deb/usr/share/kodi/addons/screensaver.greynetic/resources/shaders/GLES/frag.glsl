#version 100

varying lowp vec4 v_color;

void main ()
{
  gl_FragColor = v_color;
}
